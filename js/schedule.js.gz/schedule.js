﻿window.InitializeSchedule = () => {
    
};